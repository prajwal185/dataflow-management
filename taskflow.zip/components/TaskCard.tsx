
import React from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { Task, TaskPriority, TaskType } from '../types';
import { formatDate } from '../utils/helpers';

interface TaskCardProps {
    task: Task;
}

const TaskCard: React.FC<TaskCardProps> = ({ task }) => {
    const { state, dispatch } = useAppContext();
    const assignee = state.users.find(u => u.id === task.assigneeId);

    const openTaskModal = () => {
        dispatch({ type: 'OPEN_MODAL', payload: { modal: 'taskDetail', value: task.id } });
    };

    const handleDragStart = (e: React.DragEvent<HTMLDivElement>) => {
        e.dataTransfer.setData('text/plain', task.id);
        e.currentTarget.classList.add('opacity-50');
    };
    
    const handleDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
        e.currentTarget.classList.remove('opacity-50');
    };

    const priorityClasses: Record<TaskPriority, string> = {
        'Low': 'bg-gray-400',
        'Medium': 'bg-blue-500',
        'High': 'bg-yellow-500',
        'Critical': 'bg-red-500'
    };

    const typeClasses: Record<TaskType, string> = {
        'Task': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
        'Story': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
        'Bug': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
        'Epic': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
    };
    
    const isOverdue = task.dueDate && new Date(task.dueDate) < new Date();

    return (
        <div
            draggable
            onDragStart={handleDragStart}
            onDragEnd={handleDragEnd}
            onClick={openTaskModal}
            className="bg-white dark:bg-gray-900 rounded-lg p-3 mb-3 shadow-sm cursor-pointer border-l-4"
            style={{ borderLeftColor: priorityClasses[task.priority] }}
        >
            <div className="flex justify-between items-start mb-2">
                <span className="text-xs font-semibold text-gray-500">{task.id}</span>
                <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${typeClasses[task.type]}`}>{task.type}</span>
            </div>
            <p className="text-sm font-medium text-gray-800 dark:text-gray-100 mb-2">{task.title}</p>
            <div className="flex justify-between items-center mt-3">
                 <div className="flex items-center space-x-1 text-xs text-gray-500">
                    {task.comments > 0 && <span><i className="fas fa-comment-alt"></i> {task.comments}</span>}
                    {task.attachments > 0 && <span><i className="fas fa-paperclip"></i> {task.attachments}</span>}
                    {task.dueDate && <span className={isOverdue ? 'text-red-500' : ''}><i className="fas fa-calendar-alt"></i> {formatDate(task.dueDate)}</span>}
                </div>
                 {assignee ? (
                    <div className="w-6 h-6 rounded-full bg-blue-200 dark:bg-blue-900 flex items-center justify-center text-xs" title={assignee.name}>
                        {assignee.avatar}
                    </div>
                ) : (
                     <div className="w-6 h-6 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center text-xs text-gray-400" title="Unassigned">
                        ?
                    </div>
                )}
            </div>
        </div>
    );
};

export default TaskCard;
