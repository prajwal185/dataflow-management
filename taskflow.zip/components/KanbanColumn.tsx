
import React, { useState } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { Task, TaskStatus } from '../types';
import TaskCard from './TaskCard';

interface KanbanColumnProps {
    status: TaskStatus;
    tasks: Task[];
}

const KanbanColumn: React.FC<KanbanColumnProps> = ({ status, tasks }) => {
    const { state, dispatch } = useAppContext();
    const { currentUser } = state;
    const [isOver, setIsOver] = useState(false);

    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        setIsOver(false);
        const taskId = e.dataTransfer.getData('text/plain');
        const task = state.tasks.find(t => t.id === taskId);
        
        if (task && task.status !== status && currentUser) {
            dispatch({ type: 'UPDATE_TASK_STATUS', payload: { taskId, newStatus: status } });
            dispatch({ type: 'ADD_ACTIVITY', payload: { userId: currentUser.id, action: 'moved', taskId, details: `moved from ${task.status} to ${status}` } });
        }
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        setIsOver(true);
    };

    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
        setIsOver(false);
    };

    const columnStyles: { [key in TaskStatus]: { bg: string, text: string } } = {
        'To Do': { bg: 'border-t-blue-500', text: 'text-blue-500' },
        'In Progress': { bg: 'border-t-yellow-500', text: 'text-yellow-500' },
        'In Review': { bg: 'border-t-purple-500', text: 'text-purple-500' },
        'Done': { bg: 'border-t-green-500', text: 'text-green-500' },
    };

    return (
        <div className={`bg-gray-100 dark:bg-gray-800 rounded-lg flex flex-col h-full border-t-4 ${columnStyles[status].bg}`}>
            <div className="p-4 flex-shrink-0">
                <div className="flex justify-between items-center">
                    <h3 className={`font-semibold ${columnStyles[status].text}`}>{status}</h3>
                    <span className="text-sm font-bold bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-2 py-0.5 rounded-full">{tasks.length}</span>
                </div>
            </div>
            <div
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                className={`flex-1 p-2 overflow-y-auto transition-colors duration-300 ${isOver ? 'bg-blue-50 dark:bg-gray-700' : ''}`}
            >
                {tasks.map(task => (
                    <TaskCard key={task.id} task={task} />
                ))}
            </div>
        </div>
    );
};

export default KanbanColumn;
