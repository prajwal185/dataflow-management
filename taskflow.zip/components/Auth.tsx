
import React, { useState, FormEvent } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { getRandomAvatar } from '../utils/helpers';
import { User } from '../types';

const Auth: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const [isLogin, setIsLogin] = useState(true);

    const [loginEmail, setLoginEmail] = useState('admin@demo.com');
    const [loginPassword, setLoginPassword] = useState('demo123');

    const [signupName, setSignupName] = useState('');
    const [signupEmail, setSignupEmail] = useState('');
    const [signupPassword, setSignupPassword] = useState('');
    const [signupRole, setSignupRole] = useState('Developer');
    
    const [error, setError] = useState('');

    const handleLogin = (e: FormEvent) => {
        e.preventDefault();
        setError('');
        const user = state.users.find(u => u.email === loginEmail && u.password === loginPassword);
        if (user) {
            dispatch({ type: 'LOGIN', payload: user });
        } else {
            setError('Invalid credentials. Please try again.');
        }
    };

    const handleSignup = (e: FormEvent) => {
        e.preventDefault();
        setError('');
        if (state.users.some(u => u.email === signupEmail)) {
            setError('Email already exists. Please use a different email.');
            return;
        }
        const newUser: User = {
            id: `user${state.users.length + 1}`,
            name: signupName,
            email: signupEmail,
            password: signupPassword,
            role: signupRole,
            avatar: getRandomAvatar(),
            status: 'online',
        };
        dispatch({ type: 'ADD_USER', payload: newUser });
        dispatch({ type: 'LOGIN', payload: newUser });
    };

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center">
            <div className="relative mx-auto p-5 border w-full max-w-md shadow-lg rounded-xl bg-white dark:bg-gray-800">
                <div className="mt-3 text-center">
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Welcome to TaskFlow</h2>
                    <div className="my-4 border-b border-gray-200 dark:border-gray-700">
                        <ul className="flex flex-wrap -mb-px text-sm font-medium text-center" role="tablist">
                            <li className="mr-2" role="presentation">
                                <button className={`inline-block p-4 border-b-2 rounded-t-lg ${isLogin ? 'border-blue-500 text-blue-600' : 'border-transparent hover:text-gray-600 hover:border-gray-300 dark:hover:text-gray-300'}`} onClick={() => setIsLogin(true)}>Login</button>
                            </li>
                            <li className="mr-2" role="presentation">
                                <button className={`inline-block p-4 border-b-2 rounded-t-lg ${!isLogin ? 'border-blue-500 text-blue-600' : 'border-transparent hover:text-gray-600 hover:border-gray-300 dark:hover:text-gray-300'}`} onClick={() => setIsLogin(false)}>Sign Up</button>
                            </li>
                        </ul>
                    </div>

                    {isLogin ? (
                        <form onSubmit={handleLogin} className="px-4 py-2">
                             <div className="mb-4 text-left">
                                <label className="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" htmlFor="loginEmail">Email</label>
                                <input type="email" value={loginEmail} onChange={e => setLoginEmail(e.target.value)} id="loginEmail" className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-200 dark:bg-gray-700 leading-tight focus:outline-none focus:shadow-outline" required />
                                 <div className="mt-2 p-2 bg-blue-50 dark:bg-gray-700 rounded-md">
                                    <p className="text-xs text-gray-600 dark:text-gray-400">Demo accounts: <code className="text-blue-600 dark:text-blue-400">admin@demo.com</code>, <code className="text-blue-600 dark:text-blue-400">pm@demo.com</code>, etc. (password: <code className="text-blue-600 dark:text-blue-400">demo123</code>)</p>
                                </div>
                            </div>
                            <div className="mb-6 text-left">
                                <label className="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2" htmlFor="loginPassword">Password</label>
                                <input type="password" value={loginPassword} onChange={e => setLoginPassword(e.target.value)} id="loginPassword" className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-200 dark:bg-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline" required />
                            </div>
                            {error && <p className="text-red-500 text-xs italic mb-4">{error}</p>}
                            <button type="submit" className="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Login</button>
                        </form>
                    ) : (
                        <form onSubmit={handleSignup} className="px-4 py-2">
                            <div className="mb-4 text-left">
                                <label className="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Full Name</label>
                                <input type="text" value={signupName} onChange={e => setSignupName(e.target.value)} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-200 dark:bg-gray-700 leading-tight focus:outline-none focus:shadow-outline" required />
                            </div>
                            <div className="mb-4 text-left">
                                <label className="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Email</label>
                                <input type="email" value={signupEmail} onChange={e => setSignupEmail(e.target.value)} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-200 dark:bg-gray-700 leading-tight focus:outline-none focus:shadow-outline" required />
                            </div>
                            <div className="mb-4 text-left">
                                <label className="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Password</label>
                                <input type="password" value={signupPassword} onChange={e => setSignupPassword(e.target.value)} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-200 dark:bg-gray-700 leading-tight focus:outline-none focus:shadow-outline" required />
                            </div>
                             <div className="mb-4 text-left">
                                <label className="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Role</label>
                                <select value={signupRole} onChange={e => setSignupRole(e.target.value)} className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:text-gray-200 dark:bg-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                                    <option>Developer</option>
                                    <option>Designer</option>
                                    <option>Tester</option>
                                    <option>Project Manager</option>
                                </select>
                            </div>
                            {error && <p className="text-red-500 text-xs italic mb-4">{error}</p>}
                            <button type="submit" className="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Sign Up</button>
                        </form>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Auth;
