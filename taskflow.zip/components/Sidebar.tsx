
import React from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { View, Project } from '../types';

const Sidebar: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { currentUser, currentView, projects, currentProject } = state;

    const handleViewChange = (view: View) => {
        dispatch({ type: 'SET_VIEW', payload: view });
    };

    const handleProjectSelect = (project: Project) => {
        dispatch({ type: 'SET_CURRENT_PROJECT', payload: project });
        dispatch({ type: 'SET_VIEW', payload: View.Board });
    };

    const handleLogout = () => {
        dispatch({ type: 'LOGOUT' });
    };

    const navItems = [
        { view: View.Dashboard, icon: '📊', label: 'Dashboard' },
        { view: View.Projects, icon: '📂', label: 'Projects' },
        { view: View.Board, icon: '📋', label: 'Board' },
        { view: View.List, icon: '📄', label: 'List View' },
        { view: View.Reports, icon: '📈', label: 'Reports' },
        { view: View.Profile, icon: '⚙️', label: 'Settings' },
    ];

    return (
        <aside className="w-64 flex-shrink-0 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
            <div className="h-16 flex items-center px-4 border-b border-gray-200 dark:border-gray-700">
                <h1 className="text-xl font-bold text-blue-600 dark:text-blue-400">TaskFlow</h1>
            </div>
            <div className="flex items-center p-4 border-b border-gray-200 dark:border-gray-700">
                <div className="w-10 h-10 rounded-full bg-blue-200 dark:bg-blue-900 flex items-center justify-center text-xl mr-3">{currentUser?.avatar}</div>
                <div>
                    <p className="font-semibold text-sm text-gray-800 dark:text-gray-100">{currentUser?.name}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{currentUser?.role}</p>
                </div>
            </div>
            <nav className="flex-1 px-2 py-4 space-y-2 overflow-y-auto">
                {navItems.map(item => (
                    <button
                        key={item.view}
                        onClick={() => handleViewChange(item.view)}
                        className={`w-full flex items-center px-4 py-2 text-sm font-medium rounded-md transition-colors duration-150 ${
                            currentView === item.view
                                ? 'bg-blue-500 text-white'
                                : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                        }`}
                    >
                        <span className="mr-3">{item.icon}</span>
                        {item.label}
                    </button>
                ))}
                <div className="pt-4 mt-4 border-t border-gray-200 dark:border-gray-700">
                    <h4 className="px-4 text-xs font-semibold uppercase text-gray-500 dark:text-gray-400 mb-2">Projects</h4>
                    <div className="space-y-1">
                        {projects.map(project => (
                            <button
                                key={project.id}
                                onClick={() => handleProjectSelect(project)}
                                className={`w-full flex items-center px-4 py-2 text-sm rounded-md transition-colors duration-150 text-left ${
                                    currentProject?.id === project.id
                                        ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-200 font-semibold'
                                        : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                                }`}
                            >
                                <span className="w-3 h-3 rounded-full mr-3" style={{ backgroundColor: project.color }}></span>
                                <span className="truncate">{project.name}</span>
                            </button>
                        ))}
                    </div>
                </div>
            </nav>
            <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                <button
                    onClick={handleLogout}
                    className="w-full bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 font-bold py-2 px-4 rounded transition-colors duration-150"
                >
                    Logout
                </button>
            </div>
        </aside>
    );
};

export default Sidebar;
