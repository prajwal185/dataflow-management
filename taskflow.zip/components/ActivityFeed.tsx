
import React from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { formatTimestamp } from '../utils/helpers';

const ActivityFeed: React.FC = () => {
    const { state } = useAppContext();
    const { activity, users, tasks } = state;

    const recentActivity = activity.slice(0, 15);

    return (
        <aside className="w-80 flex-shrink-0 bg-white dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 flex flex-col">
            <div className="h-16 flex items-center px-4 border-b border-gray-200 dark:border-gray-700">
                <h3 className="font-semibold text-gray-800 dark:text-gray-100">Activity Feed</h3>
            </div>
            <div className="flex-1 p-4 space-y-4 overflow-y-auto">
                {recentActivity.length > 0 ? recentActivity.map(act => {
                    const user = users.find(u => u.id === act.userId);
                    const task = act.taskId ? tasks.find(t => t.id === act.taskId) : null;
                    
                    return (
                        <div key={act.id} className="flex items-start">
                            <div className="w-8 h-8 rounded-full bg-blue-200 dark:bg-blue-900 flex items-center justify-center text-sm mr-3 flex-shrink-0">{user?.avatar}</div>
                            <div className="flex-1">
                                <p className="text-sm text-gray-700 dark:text-gray-300">
                                    <span className="font-semibold">{user?.name || 'Unknown'}</span>
                                    <span dangerouslySetInnerHTML={{ __html: ` ${act.details} ` }} />
                                    {task && <strong className="font-semibold">{task.id}</strong>}
                                </p>
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{formatTimestamp(act.timestamp)}</p>
                            </div>
                        </div>
                    );
                }) : (
                     <p className="text-sm text-gray-500 dark:text-gray-400 text-center mt-4">No recent activity.</p>
                )}
            </div>
        </aside>
    );
};

export default ActivityFeed;
