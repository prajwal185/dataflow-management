
import React, { useState, useEffect } from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { Task, TaskPriority, TaskStatus, TaskType, Comment } from '../../types';
import { formatTimestamp } from '../../utils/helpers';

interface TaskDetailModalProps {
    taskId: string;
}

const TaskDetailModal: React.FC<TaskDetailModalProps> = ({ taskId }) => {
    const { state, dispatch } = useAppContext();
    const { users, currentUser } = state;
    const task = state.tasks.find(t => t.id === taskId);
    const taskComments = state.comments.filter(c => c.taskId === taskId);

    const [updatedTask, setUpdatedTask] = useState<Task | null>(task || null);
    const [newComment, setNewComment] = useState('');

    useEffect(() => {
        setUpdatedTask(task || null);
    }, [task]);

    if (!updatedTask || !currentUser) return null;

    const closeModal = () => {
        dispatch({ type: 'CLOSE_MODAL', payload: 'taskDetail' });
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setUpdatedTask(prev => prev ? { ...prev, [name]: value } : null);
    };

    const handleSaveChanges = () => {
        if (updatedTask) {
            dispatch({ type: 'UPDATE_TASK', payload: updatedTask });
            dispatch({ type: 'ADD_ACTIVITY', payload: { userId: currentUser.id, action: 'updated', taskId: updatedTask.id, details: 'updated task details' } });
            closeModal();
        }
    };

    const handleDelete = () => {
        if (window.confirm(`Are you sure you want to delete task ${updatedTask.id}?`)) {
            dispatch({ type: 'DELETE_TASK', payload: updatedTask.id });
             dispatch({ type: 'ADD_ACTIVITY', payload: { userId: currentUser.id, action: 'deleted', taskId: updatedTask.id, details: 'deleted task' } });
            closeModal();
        }
    };
    
    const handleAddComment = () => {
        if (!newComment.trim()) return;
        const comment: Comment = {
            id: `comment${Date.now()}`,
            taskId: updatedTask.id,
            userId: currentUser.id,
            content: newComment,
            timestamp: new Date().toISOString(),
        };
        dispatch({type: 'ADD_COMMENT', payload: comment});
        dispatch({ type: 'ADD_ACTIVITY', payload: { userId: currentUser.id, action: 'commented', taskId: updatedTask.id, details: 'added a comment on' } });
        setNewComment('');
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4" onClick={closeModal}>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-4xl max-h-full overflow-y-auto" onClick={e => e.stopPropagation()}>
                <div className="p-6">
                    <div className="flex justify-between items-center pb-4 border-b border-gray-200 dark:border-gray-700">
                        <h3 className="text-xl font-semibold">{updatedTask.id} - {updatedTask.title}</h3>
                        <button onClick={closeModal} className="text-gray-400 text-2xl hover:text-gray-600 dark:hover:text-gray-300">&times;</button>
                    </div>
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-4">
                        <div className="lg:col-span-2 space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Title</label>
                                <input type="text" name="title" value={updatedTask.title} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600"/>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Description</label>
                                <textarea name="description" value={updatedTask.description} onChange={handleChange} rows={5} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600"></textarea>
                            </div>
                            <div className="space-y-4">
                               <h4 className="text-md font-semibold">Comments</h4>
                               <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                                   {taskComments.map(comment => {
                                       const user = users.find(u => u.id === comment.userId);
                                       return (
                                           <div key={comment.id} className="flex items-start">
                                                <div className="w-8 h-8 rounded-full bg-blue-200 dark:bg-blue-900 flex items-center justify-center text-sm mr-3 flex-shrink-0">{user?.avatar}</div>
                                                <div className="flex-1 bg-gray-100 dark:bg-gray-700 p-3 rounded-lg">
                                                    <div className="flex justify-between items-center">
                                                        <span className="font-semibold text-sm">{user?.name}</span>
                                                        <span className="text-xs text-gray-500 dark:text-gray-400">{formatTimestamp(comment.timestamp)}</span>
                                                    </div>
                                                    <p className="text-sm mt-1">{comment.content}</p>
                                                </div>
                                           </div>
                                       );
                                   })}
                               </div>
                               <div>
                                    <textarea value={newComment} onChange={e => setNewComment(e.target.value)} rows={3} placeholder="Add a comment..." className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm dark:bg-gray-700 dark:border-gray-600"></textarea>
                                    <button onClick={handleAddComment} className="mt-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700">Add Comment</button>
                               </div>
                            </div>
                        </div>
                        <div className="space-y-4 lg:border-l lg:pl-6 lg:border-gray-200 lg:dark:border-gray-700">
                             <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Status</label>
                                <select name="status" value={updatedTask.status} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm sm:text-sm dark:bg-gray-700 dark:border-gray-600">
                                    <option>To Do</option><option>In Progress</option><option>In Review</option><option>Done</option>
                                </select>
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Assignee</label>
                                <select name="assigneeId" value={updatedTask.assigneeId || ''} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm sm:text-sm dark:bg-gray-700 dark:border-gray-600">
                                    <option value="">Unassigned</option>
                                    {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Priority</label>
                                 <select name="priority" value={updatedTask.priority} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm sm:text-sm dark:bg-gray-700 dark:border-gray-600">
                                    <option>Low</option><option>Medium</option><option>High</option><option>Critical</option>
                                </select>
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Type</label>
                                 <select name="type" value={updatedTask.type} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm sm:text-sm dark:bg-gray-700 dark:border-gray-600">
                                    <option>Task</option><option>Story</option><option>Bug</option><option>Epic</option>
                                </select>
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Due Date</label>
                                <input type="date" name="dueDate" value={updatedTask.dueDate || ''} onChange={handleChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm sm:text-sm dark:bg-gray-700 dark:border-gray-600"/>
                            </div>
                             <div className="pt-4 space-y-2">
                                <button onClick={handleSaveChanges} className="w-full px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">Save Changes</button>
                                <button onClick={handleDelete} className="w-full px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">Delete Task</button>
                                <button onClick={closeModal} className="w-full px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300 dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TaskDetailModal;
