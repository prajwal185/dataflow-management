import React from 'react';
import { useAppContext } from '../../hooks/useAppContext';
// FIX: Import `View` enum to use for strongly typed view state.
import { Project, View } from '../../types';

const ProjectsView: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { projects, users, tasks } = state;

    const openCreateProjectModal = () => {
        dispatch({ type: 'OPEN_MODAL', payload: { modal: 'createProject', value: true } });
    };

    const handleProjectSelect = (project: Project) => {
        dispatch({ type: 'SET_CURRENT_PROJECT', payload: project });
        // FIX: Use `View.Board` enum member instead of the string 'board' to match the action payload type.
        dispatch({ type: 'SET_VIEW', payload: View.Board });
    };

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-semibold">All Projects</h2>
                <button
                    onClick={openCreateProjectModal}
                    className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-150 flex items-center"
                >
                    <i className="fas fa-plus mr-2"></i>
                    New Project
                </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {projects.map(project => {
                    const lead = users.find(u => u.id === project.lead);
                    const projectTasks = tasks.filter(t => t.projectId === project.id);
                    const completedTasks = projectTasks.filter(t => t.status === 'Done').length;
                    const progress = projectTasks.length > 0 ? Math.round((completedTasks / projectTasks.length) * 100) : 0;
                    
                    return (
                        <div
                            key={project.id}
                            onClick={() => handleProjectSelect(project)}
                            className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 cursor-pointer hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
                        >
                            <div className="flex justify-between items-start mb-4">
                                <h3 className="font-bold text-lg">{project.name}</h3>
                                <span className="text-xs font-semibold bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-2 py-1 rounded-full">{project.key}</span>
                            </div>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4 h-10 overflow-hidden">{project.description}</p>
                            <div className="mb-4">
                                <div className="flex justify-between items-center text-sm text-gray-500 dark:text-gray-400 mb-1">
                                    <span>Progress</span>
                                    <span>{progress}%</span>
                                </div>
                                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                                    <div className="h-2 rounded-full" style={{ width: `${progress}%`, backgroundColor: project.color }}></div>
                                </div>
                            </div>
                            <div className="flex justify-between items-center pt-4 border-t border-gray-200 dark:border-gray-700">
                                <div className="flex items-center">
                                    <div className="w-8 h-8 rounded-full bg-blue-200 dark:bg-blue-900 flex items-center justify-center text-sm mr-2">{lead?.avatar}</div>
                                    <span className="text-sm font-medium">{lead?.name || 'Unassigned'}</span>
                                </div>
                                <span className={`text-xs font-bold capitalize px-3 py-1 rounded-full ${project.status === 'active' ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-200' : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-200'}`}>
                                    {project.status}
                                </span>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default ProjectsView;