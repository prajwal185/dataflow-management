
import React, { useMemo } from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { TaskStatus, Project } from '../../types';
import KanbanColumn from '../KanbanColumn';

const BoardView: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { currentProject, tasks, projects, users } = state;

    const handleProjectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newProject = projects.find(p => p.id === e.target.value) || null;
        dispatch({ type: 'SET_CURRENT_PROJECT', payload: newProject });
    };

    const projectTasks = useMemo(() => {
        return tasks.filter(task => task.projectId === currentProject?.id);
    }, [tasks, currentProject]);

    const columns: TaskStatus[] = ['To Do', 'In Progress', 'In Review', 'Done'];

    if (!currentProject) {
        return (
            <div className="flex items-center justify-center h-full">
                <div className="text-center">
                    <p className="text-xl font-semibold">Please select a project to view the board.</p>
                     <select onChange={handleProjectChange} defaultValue="" className="mt-4 form-select block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600">
                        <option value="" disabled>Select a project</option>
                        {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                </div>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full">
            <div className="flex items-center justify-between mb-4 flex-shrink-0">
                <div className="flex items-center space-x-4">
                     <select value={currentProject.id} onChange={handleProjectChange} className="font-semibold text-lg bg-transparent border-0 focus:ring-0 dark:text-white">
                        {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                </div>
                 <div className="flex items-center space-x-2">
                    <select className="form-select block w-40 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600">
                        <option value="">All Assignees</option>
                        {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                    </select>
                     <select className="form-select block w-40 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600">
                        <option value="">All Priorities</option>
                        <option>Low</option>
                        <option>Medium</option>
                        <option>High</option>
                        <option>Critical</option>
                    </select>
                </div>
            </div>
            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 overflow-x-auto pb-4">
                {columns.map(status => (
                    <KanbanColumn
                        key={status}
                        status={status}
                        tasks={projectTasks.filter(task => task.status === status)}
                    />
                ))}
            </div>
        </div>
    );
};

export default BoardView;
