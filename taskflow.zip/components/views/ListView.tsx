
import React from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { formatDate } from '../../utils/helpers';
import { Task, TaskPriority, TaskStatus, TaskType } from '../../types';

const ListView: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { tasks, users, projects } = state;

    const openTaskModal = (taskId: string) => {
        dispatch({ type: 'OPEN_MODAL', payload: { modal: 'taskDetail', value: taskId } });
    };

    const getStatusClass = (status: TaskStatus) => {
        const map = {
            'To Do': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
            'In Progress': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
            'In Review': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
            'Done': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
        };
        return map[status] || 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
    };

    const getPriorityClass = (priority: TaskPriority) => {
        const map = {
            'Low': 'text-gray-500', 'Medium': 'text-blue-500', 'High': 'text-yellow-500', 'Critical': 'text-red-500'
        };
        return map[priority];
    };
    
     const getTypeClass = (type: TaskType) => {
        const map = {
            'Task': 'bg-blue-100 text-blue-800',
            'Story': 'bg-green-100 text-green-800',
            'Bug': 'bg-red-100 text-red-800',
            'Epic': 'bg-purple-100 text-purple-800',
        };
        return map[type] || 'bg-gray-100 text-gray-800';
    };

    return (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md">
            <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center space-x-4">
                 <select className="form-select block w-48 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600">
                    <option value="">All Projects</option>
                     {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
                 <select className="form-select block w-48 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600">
                    <option value="">All Statuses</option>
                    <option>To Do</option>
                    <option>In Progress</option>
                    <option>In Review</option>
                    <option>Done</option>
                </select>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" className="px-6 py-3">Task</th>
                            <th scope="col" className="px-6 py-3">Type</th>
                            <th scope="col" className="px-6 py-3">Status</th>
                            <th scope="col" className="px-6 py-3">Priority</th>
                            <th scope="col" className="px-6 py-3">Assignee</th>
                            <th scope="col" className="px-6 py-3">Due Date</th>
                            <th scope="col" className="px-6 py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {tasks.map(task => {
                            const assignee = users.find(u => u.id === task.assigneeId);
                            const project = projects.find(p => p.id === task.projectId);
                            return (
                                <tr key={task.id} className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 cursor-pointer" onClick={() => openTaskModal(task.id)}>
                                    <td className="px-6 py-4">
                                        <div className="font-medium text-gray-900 dark:text-white">{task.id} - {task.title}</div>
                                        <div className="text-xs text-gray-500">{project?.name}</div>
                                    </td>
                                    <td className="px-6 py-4"><span className={`px-2 py-1 text-xs font-medium rounded-full ${getTypeClass(task.type)}`}>{task.type}</span></td>
                                    <td className="px-6 py-4"><span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusClass(task.status)}`}>{task.status}</span></td>
                                    <td className={`px-6 py-4 font-medium ${getPriorityClass(task.priority)}`}>{task.priority}</td>
                                    <td className="px-6 py-4 flex items-center">
                                        {assignee ? (
                                            <>
                                                <div className="w-6 h-6 rounded-full bg-blue-200 flex items-center justify-center text-xs mr-2">{assignee.avatar}</div>
                                                {assignee.name}
                                            </>
                                        ) : 'Unassigned'}
                                    </td>
                                    <td className="px-6 py-4">{formatDate(task.dueDate)}</td>
                                    <td className="px-6 py-4">
                                        <button onClick={(e) => { e.stopPropagation(); openTaskModal(task.id); }} className="font-medium text-blue-600 dark:text-blue-500 hover:underline">View</button>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default ListView;
