
import React from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { formatTimestamp } from '../../utils/helpers';
import { TaskStatus } from '../../types';

const Dashboard: React.FC = () => {
    const { state } = useAppContext();
    const { users, projects, tasks, activity, currentUser } = state;

    // Recent Activity
    const recentActivity = activity.slice(0, 5);

    // Project Overview
    const activeProjects = projects.filter(p => p.status === 'active').length;

    // My Tasks
    const myTasks = tasks.filter(t => t.assigneeId === currentUser?.id);
    const myTasksByStatus = {
        'To Do': myTasks.filter(t => t.status === 'To Do').length,
        'In Progress': myTasks.filter(t => t.status === 'In Progress').length,
        'In Review': myTasks.filter(t => t.status === 'In Review').length,
        'Done': myTasks.filter(t => t.status === 'Done').length,
    };

    // Team Activity
    const onlineUsers = users.filter(u => u.status === 'online');

    const statusColors: Record<string, string> = {
        online: 'bg-green-500',
        away: 'bg-yellow-500',
        offline: 'bg-gray-500'
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Project Overview */}
            <div className="lg:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold mb-4">Project Overview</h3>
                <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                        <p className="text-3xl font-bold text-blue-500">{projects.length}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Total Projects</p>
                    </div>
                    <div>
                        <p className="text-3xl font-bold text-green-500">{activeProjects}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Active Projects</p>
                    </div>
                    <div>
                        <p className="text-3xl font-bold text-purple-500">{tasks.length}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Total Tasks</p>
                    </div>
                </div>
            </div>

            {/* My Tasks */}
            <div className="lg:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold mb-4">My Tasks</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    {Object.entries(myTasksByStatus).map(([status, count]) => (
                        <div key={status}>
                            <p className="text-3xl font-bold">{count}</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{status}</p>
                        </div>
                    ))}
                </div>
            </div>

            {/* Recent Activity */}
            <div className="lg:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
                <div className="space-y-4">
                    {recentActivity.map(act => {
                        const user = users.find(u => u.id === act.userId);
                        return (
                             <div key={act.id} className="flex items-center">
                                <div className="w-8 h-8 rounded-full bg-blue-200 dark:bg-blue-900 flex items-center justify-center text-sm mr-3 flex-shrink-0">{user?.avatar}</div>
                                <div className="flex-1">
                                    <p className="text-sm text-gray-700 dark:text-gray-300">
                                        <span className="font-semibold">{user?.name || 'Unknown'}</span>
                                        <span dangerouslySetInnerHTML={{ __html: ` ${act.details} `}} />
                                        {act.taskId && <strong>{act.taskId}</strong>}
                                    </p>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">{formatTimestamp(act.timestamp)}</p>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

             {/* Team Activity */}
            <div className="lg:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold mb-4">Team Activity</h3>
                <div className="space-y-3">
                    {onlineUsers.map(user => (
                        <div key={user.id} className="flex items-center justify-between">
                            <div className="flex items-center">
                               <div className="w-8 h-8 rounded-full bg-blue-200 dark:bg-blue-900 flex items-center justify-center text-sm mr-3">{user.avatar}</div>
                               <div>
                                   <p className="text-sm font-medium">{user.name}</p>
                                   <p className="text-xs text-gray-500 dark:text-gray-400">{user.role}</p>
                               </div>
                            </div>
                            <div className="flex items-center">
                                <span className={`h-2.5 w-2.5 rounded-full mr-2 ${statusColors[user.status]}`}></span>
                                <span className="text-xs capitalize">{user.status}</span>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
