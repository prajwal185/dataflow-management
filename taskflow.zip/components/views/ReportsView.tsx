
import React, { useMemo } from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const ReportsView: React.FC = () => {
    const { state } = useAppContext();
    const { tasks, projects } = state;

    const taskDistributionData = useMemo(() => {
        const counts = { 'To Do': 0, 'In Progress': 0, 'In Review': 0, 'Done': 0 };
        tasks.forEach(task => {
            counts[task.status]++;
        });
        return Object.entries(counts).map(([name, value]) => ({ name, value }));
    }, [tasks]);
    
    const projectProgressData = useMemo(() => {
        return projects.map(project => {
            const projectTasks = tasks.filter(t => t.projectId === project.id);
            const completedTasks = projectTasks.filter(t => t.status === 'Done').length;
            const progress = projectTasks.length > 0 ? Math.round((completedTasks / projectTasks.length) * 100) : 0;
            return { name: project.name, progress };
        });
    }, [projects, tasks]);
    
    const COLORS = ['#0088FE', '#FFBB28', '#8884d8', '#00C49F'];

    return (
        <div>
            <h2 className="text-2xl font-semibold mb-6">Reports</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                    <h3 className="text-lg font-semibold mb-4">Task Distribution by Status</h3>
                    <div style={{ width: '100%', height: 300 }}>
                         <ResponsiveContainer>
                            <PieChart>
                                <Pie data={taskDistributionData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8" label>
                                    {taskDistributionData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                                </Pie>
                                <Tooltip />
                                <Legend />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </div>
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                     <h3 className="text-lg font-semibold mb-4">Project Progress</h3>
                    <div style={{ width: '100%', height: 300 }}>
                        <ResponsiveContainer>
                            <BarChart data={projectProgressData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                <XAxis dataKey="name" />
                                <YAxis unit="%" />
                                <Tooltip />
                                <Legend />
                                <Bar dataKey="progress" fill="#82ca9d" />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ReportsView;
