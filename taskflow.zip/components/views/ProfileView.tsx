
import React from 'react';
import { useAppContext } from '../../hooks/useAppContext';

const ProfileView: React.FC = () => {
    const { state } = useAppContext();
    const { currentUser } = state;

    if (!currentUser) {
        return <div>Loading profile...</div>;
    }

    const statusColors: Record<string, string> = {
        online: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
        away: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
        offline: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
    };

    return (
        <div>
            <h2 className="text-2xl font-semibold mb-6">Profile & Settings</h2>
            <div className="bg-white dark:bg-gray-800 max-w-2xl mx-auto rounded-lg shadow-md p-8">
                <div className="flex items-center space-x-6 pb-6 border-b border-gray-200 dark:border-gray-700 mb-6">
                     <div className="w-24 h-24 rounded-full bg-blue-200 dark:bg-blue-900 flex items-center justify-center text-5xl flex-shrink-0">{currentUser.avatar}</div>
                    <div>
                        <h3 className="text-2xl font-bold">{currentUser.name}</h3>
                        <p className="text-md text-gray-500 dark:text-gray-400">{currentUser.role}</p>
                         <span className={`mt-2 inline-block px-3 py-1 text-xs font-semibold rounded-full ${statusColors[currentUser.status]}`}>
                            {currentUser.status.charAt(0).toUpperCase() + currentUser.status.slice(1)}
                        </span>
                    </div>
                </div>
                <div className="space-y-4">
                     <div>
                        <label className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Email Address</label>
                        <input type="email" value={currentUser.email} readOnly className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-gray-100 dark:bg-gray-700 cursor-not-allowed" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Role</label>
                        <input type="text" value={currentUser.role} readOnly className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-gray-100 dark:bg-gray-700 cursor-not-allowed" />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProfileView;
