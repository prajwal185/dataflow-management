
import React from 'react';
import { useAppContext } from '../hooks/useAppContext';

const Header: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { currentView, currentProject } = state;
    
    const pageTitle = currentView.charAt(0).toUpperCase() + currentView.slice(1);
    
    const breadcrumb = currentProject && (currentView === 'board' || currentView === 'list') 
        ? `${currentProject.name} > ${pageTitle}`
        : pageTitle;

    const openCreateTaskModal = () => {
        dispatch({ type: 'OPEN_MODAL', payload: { modal: 'createTask', value: true } });
    };

    return (
        <header className="h-16 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex-shrink-0 flex items-center justify-between px-6">
            <div>
                <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">{pageTitle}</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400">{breadcrumb}</p>
            </div>
            <div className="flex items-center space-x-4">
                <div className="relative">
                    <input
                        type="text"
                        placeholder="Search tasks..."
                        className="pl-10 pr-4 py-2 w-64 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <i className="fas fa-search text-gray-400"></i>
                    </div>
                </div>
                <button
                    onClick={openCreateTaskModal}
                    className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-150 flex items-center"
                >
                    <i className="fas fa-plus mr-2"></i>
                    Create Task
                </button>
            </div>
        </header>
    );
};

export default Header;
