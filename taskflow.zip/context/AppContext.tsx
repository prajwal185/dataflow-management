
import React, { createContext, useReducer, useEffect, ReactNode } from 'react';
import { User, Project, Task, Comment, Activity, View, TaskStatus } from '../types';
import { sampleData } from '../constants';

interface AppState {
    currentUser: User | null;
    currentProject: Project | null;
    currentView: View;
    projects: Project[];
    tasks: Task[];
    users: User[];
    comments: Comment[];
    activity: Activity[];
    filters: {
        assignee: string;
        priority: string;
        status: string;
        project: string;
    };
    modals: {
        createTask: boolean;
        createProject: boolean;
        taskDetail: string | null;
    };
}

type Action =
    | { type: 'LOGIN'; payload: User }
    | { type: 'LOGOUT' }
    | { type: 'SET_VIEW'; payload: View }
    | { type: 'SET_CURRENT_PROJECT'; payload: Project | null }
    | { type: 'OPEN_MODAL'; payload: { modal: keyof AppState['modals']; value: any } }
    | { type: 'CLOSE_MODAL'; payload: keyof AppState['modals'] }
    | { type: 'ADD_USER'; payload: User }
    | { type: 'ADD_PROJECT'; payload: Project }
    | { type: 'ADD_TASK'; payload: Task }
    | { type: 'UPDATE_TASK'; payload: Task }
    | { type: 'UPDATE_TASK_STATUS'; payload: { taskId: string; newStatus: TaskStatus } }
    | { type: 'DELETE_TASK'; payload: string }
    | { type: 'ADD_COMMENT'; payload: Comment }
    | { type: 'ADD_ACTIVITY'; payload: Omit<Activity, 'id' | 'timestamp'> }
    | { type: 'SET_STATE'; payload: AppState };


const initialState: AppState = {
    currentUser: null,
    currentProject: null,
    currentView: View.Dashboard,
    projects: [],
    tasks: [],
    users: [],
    comments: [],
    activity: [],
    filters: {
        assignee: '',
        priority: '',
        status: '',
        project: '',
    },
    modals: {
        createTask: false,
        createProject: false,
        taskDetail: null,
    },
};

const appReducer = (state: AppState, action: Action): AppState => {
    switch (action.type) {
        case 'LOGIN':
            sessionStorage.setItem('taskflow_currentUser', action.payload.id);
            return { ...state, currentUser: action.payload };
        case 'LOGOUT':
            sessionStorage.removeItem('taskflow_currentUser');
            return { ...state, currentUser: null };
        case 'SET_VIEW':
            return { ...state, currentView: action.payload };
        case 'SET_CURRENT_PROJECT':
            return { ...state, currentProject: action.payload };
        case 'OPEN_MODAL':
            return { ...state, modals: { ...state.modals, [action.payload.modal]: action.payload.value } };
        case 'CLOSE_MODAL':
             const newModals = { ...state.modals, [action.payload]: action.payload === 'taskDetail' ? null : false };
            return { ...state, modals: newModals };
        case 'ADD_USER':
            return { ...state, users: [...state.users, action.payload] };
        case 'ADD_PROJECT':
            return { ...state, projects: [...state.projects, action.payload] };
        case 'ADD_TASK':
            return { ...state, tasks: [...state.tasks, action.payload] };
        case 'UPDATE_TASK':
            return { ...state, tasks: state.tasks.map(t => t.id === action.payload.id ? action.payload : t) };
        case 'UPDATE_TASK_STATUS':
             return {...state, tasks: state.tasks.map(t => t.id === action.payload.taskId ? {...t, status: action.payload.newStatus} : t)};
        case 'DELETE_TASK':
            return { 
                ...state, 
                tasks: state.tasks.filter(t => t.id !== action.payload),
                comments: state.comments.filter(c => c.taskId !== action.payload) 
            };
        case 'ADD_COMMENT':
            const taskToUpdate = state.tasks.find(t => t.id === action.payload.taskId);
            const updatedTasks = taskToUpdate
                ? state.tasks.map(t => t.id === action.payload.taskId ? { ...t, comments: t.comments + 1 } : t)
                : state.tasks;
            return { ...state, comments: [...state.comments, action.payload], tasks: updatedTasks };
        case 'ADD_ACTIVITY':
            const newActivity: Activity = {
                ...action.payload,
                id: `act${Date.now()}`,
                timestamp: new Date().toISOString()
            };
            return { ...state, activity: [newActivity, ...state.activity] };
        case 'SET_STATE':
            return action.payload;
        default:
            return state;
    }
};

export const AppContext = createContext<{ state: AppState; dispatch: React.Dispatch<Action> }>({
    state: initialState,
    dispatch: () => null,
});

export const AppProvider: React.FC<{children: ReactNode}> = ({ children }) => {
    const [state, dispatch] = useReducer(appReducer, initialState);

    useEffect(() => {
        try {
            const savedState = localStorage.getItem('taskflow_appState');
            const loggedInUserId = sessionStorage.getItem('taskflow_currentUser');
            
            let loadedState: AppState = initialState;

            if (savedState) {
                const parsedState = JSON.parse(savedState);
                loadedState = { ...initialState, ...parsedState };
            } else {
                loadedState = { ...initialState, ...sampleData, currentProject: sampleData.projects[0] || null };
            }
            
            if (loggedInUserId) {
                const user = loadedState.users.find(u => u.id === loggedInUserId);
                if (user) {
                    loadedState.currentUser = user;
                }
            }
            
            dispatch({ type: 'SET_STATE', payload: loadedState });

        } catch (error) {
            console.error("Failed to load state from storage", error);
            const initialData = { ...initialState, ...sampleData, currentProject: sampleData.projects[0] || null };
            dispatch({ type: 'SET_STATE', payload: initialData });
        }
    }, []);

    useEffect(() => {
        if (state !== initialState) {
             try {
                const stateToSave = { ...state, currentUser: null }; // Don't persist currentUser in localStorage
                localStorage.setItem('taskflow_appState', JSON.stringify(stateToSave));
            } catch (error) {
                console.error("Failed to save state to storage", error);
            }
        }
    }, [state]);

    return (
        <AppContext.Provider value={{ state, dispatch }}>
            {children}
        </AppContext.Provider>
    );
};
